export const demoTicketData = [
  {
    id: 1,
    name: "ticket 1",
    description: "resolve ticket 1",
  },
  {
    id: 2,
    name: "ticket 2",
    description: "resolve ticket 2",
  },
  {
    id: 3,
    name: "ticket 3",
    description: "resolve ticket 3",
  },
  {
    id: 4,
    name: "ticket 4",
    description: "resolve ticket 4",
  },
  {
    id: 5,
    name: "ticket 5",
    description: "resolve ticket 5",
  },
];
export const demoCustomerData = [
    {
      id: 1,
      name: "Customer 1",
      description: " Customer 1",
    },
    {
      id: 2,
      name: "Customer 2",
      description: " Customer 2",
    },
    {
      id: 3,
      name: "Customer 3",
      description: " Customer 3",
    },
    {
      id: 4,
      name: "Customer 4",
      description: " Customer 4",
    },
    {
      id: 5,
      name: "Customer 5",
      description: " Customer 5",
    },
  ];
  export const demoEngineerData = [
    {
      id: 1,
      name: "Engineer 1",
      description: " engineer 1",
    },
    {
      id: 2,
      name: "Engineer 2",
      description: " Engineer 2",
    },
    {
      id: 3,
      name: "Engineer 3",
      description: " Engineer 3",
    },
    {
      id: 4,
      name: "Engineer 4",
      description: " Engineer 4",
    },
    {
      id: 5,
      name: "Engineer 5",
      description: " Engineer 5",
    },
  ];
